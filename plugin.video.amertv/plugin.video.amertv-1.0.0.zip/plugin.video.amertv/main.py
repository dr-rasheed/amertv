# -*- coding: utf-8 -*-
# ==============================================================================
# Kodi Addon: AmerTV Matrix & ZombiB Repository (plugin.video.amertv)
# Repository Host: https://dr-rasheed.github.io/amertv
# Auto-Generated Python Core (Kodi 19 Matrix / 20 Nexus / 21 Omega)
# Includes: Multi-Source Scraping, Auto Database Sync, Auto Next Episode
# ==============================================================================
import traceback
import xbmcgui

try:
    import sys
    import os
    import urllib.parse
    import json
    import time
    import re
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcvfs
    import requests
    import traceback
    import base64
    from bs4 import BeautifulSoup
    
    HANDLE = int(sys.argv[1])
    BASE_URL = sys.argv[0]
    ADDON_ID = "plugin.video.amertv"
    REMOTE_DB_URL = "https://raw.githubusercontent.com/dr-rasheed/amertv/main/media_database.json"
    
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8',
    }
    
    def get_local_db_path():
        profile_path = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/")
        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdirs(profile_path)
        return os.path.join(profile_path, "media_database.json")
    
    def load_database():
        db_path = get_local_db_path()
        check_and_update_db(db_path)
        if xbmcvfs.exists(db_path):
            try:
                with open(db_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] Error reading local DB: {e}", xbmc.LOGINFO)
        return EMBEDDED_DATABASE
    
    def check_and_update_db(db_path):
        try:
            response = requests.get(REMOTE_DB_URL, headers=HEADERS, timeout=5)
            if response.status_code == 200:
                remote_data = response.json()
                should_update = True
                if xbmcvfs.exists(db_path):
                    with open(db_path, 'r', encoding='utf-8') as f:
                        local_data = json.load(f)
                        if local_data.get('version') == remote_data.get('version'):
                            should_update = False
                if should_update:
                    with open(db_path, 'w', encoding='utf-8') as f:
                        json.dump(remote_data, f, ensure_ascii=False, indent=2)
                    xbmcgui.Dialog().notification("AmerTV Repository", "تم تحديث مكتبة الأفلام والمسلسلات بنجاح!", 'info', 3000)
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] Online DB sync skipped: {e}", xbmc.LOGINFO)
    
    def get_params():
        param = {}
        paramstring = sys.argv[2]
        if len(paramstring) >= 2:
            cleaned = paramstring.replace('?', '')
            pairs = cleaned.split('&')
            for pair in pairs:
                split = pair.split('=')
                if len(split) == 2:
                    param[split[0]] = urllib.parse.unquote_plus(split[1])
        return param
    
    def set_video_info(li, title, plot=''):
        if hasattr(li, 'getVideoInfoTag'):
            info = li.getVideoInfoTag()
            info.setTitle(title)
            if plot:
                info.setPlot(plot)
        else:
            li.setInfo('video', {'title': title, 'plot': plot})
    
    def add_folder(name, mode, url='', icon='', plot='', category=''):
        params = {'mode': mode, 'url': url, 'name': name, 'category': category}
        target = f"{BASE_URL}?{urllib.parse.urlencode(params)}"
        li = xbmcgui.ListItem(label=name)
        if icon:
            li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
        if plot or name:
            set_video_info(li, name, plot)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=target, listitem=li, isFolder=True)
    
    def add_video_item(name, mode, item_id='', season_num=0, ep_num=0, icon='', plot=''):
        params = { 'mode': mode, 'item_id': item_id, 'season': season_num, 'episode': ep_num, 'name': name }
        target = f"{BASE_URL}?{urllib.parse.urlencode(params)}"
        li = xbmcgui.ListItem(label=name)
        if icon:
            li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
        if plot or name:
            set_video_info(li, name, plot)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=target, listitem=li, isFolder=False)
    
    def main_menu():
        xbmcplugin.setContent(HANDLE, 'files')
        add_folder("🔥 أحدث الإضافات والتحديثات (الكل مرتب)", "view_all_sorted", icon="", plot="جميع الأفلام والمسلسلات مرتبة من الأحدث للأقدم")
        add_folder("🎬 أفلام عربية", "view_category", category="أفلام عربية", plot="أحدث الأفلام العربية بمصادر سيرفرات متعددة")
        add_folder("🍿 أفلام أجنبية مترجمة", "view_category", category="أفلام أجنبية", plot="أفلام هوليوود والغربية مترجمة بأعلى دقة")
        add_folder("📺 مسلسلات عربية", "view_category", category="مسلسلات عربية", plot="مسلسلات رمضان والدراما العربية مع الانتقال التلقائي بين الحلقات")
        add_folder("🌍 مسلسلات أجنبية", "view_category", category="مسلسلات أجنبية", plot="مسلسلات أجنبية عالمية مترجمة")
        add_folder("⛩️ أنمي وكرتون", "view_category", category="أنمي", plot="حلقات وأفلام الأنمي المترجمة والمدبلجة")
        add_folder("🔄 فحص تحديث قاعدة البيانات الان", "force_update_db", plot="تحديث دليل الأفلام والمسلسلات من مستودع GitHub")
        xbmcplugin.endOfDirectory(HANDLE)
    
    def view_items(category=None):
        data = load_database()
        items = data.get('items', [])
        if category:
            items = [i for i in items if i.get('category') == category]
        items.sort(key=lambda x: x.get('dateAdded', ''), reverse=True)
        for item in items:
            item_type = item.get('type')
            title = f"[{item.get('year', '')}] {item.get('title')}"
            icon = item.get('poster', '')
            plot = item.get('description', '')
            if item_type == 'movie':
                add_video_item(f"🎬 {title}", 'play_movie', item_id=item.get('id'), icon=icon, plot=plot)
            else:
                add_folder(f"📺 {title}", 'view_seasons', url=item.get('id'), icon=icon, plot=plot)
        xbmcplugin.endOfDirectory(HANDLE)
    
    def view_seasons(item_id):
        data = load_database()
        item = next((i for i in data.get('items', []) if i.get('id') == item_id), None)
        if not item or 'seasons' not in item:
            xbmcgui.Dialog().notification("خطأ", "لم يتم العثور على مواسم لهذا المسلسل", 'warning')
            return
        for season in item.get('seasons', []):
            s_num = season.get('seasonNumber')
            s_title = season.get('title', f"الموسم {s_num}")
            add_folder(f"📂 {s_title}", 'view_episodes', url=f"{item_id}|{s_num}", icon=item.get('poster', ''), plot=item.get('description', ''))
        xbmcplugin.endOfDirectory(HANDLE)
    
    def view_episodes(season_payload):
        item_id, season_num = season_payload.split('|')
        season_num = int(season_num)
        data = load_database()
        item = next((i for i in data.get('items', []) if i.get('id') == item_id), None)
        if not item: return
        season = next((s for s in item.get('seasons', []) if s.get('seasonNumber') == season_num), None)
        if not season: return
        for ep in season.get('episodes', []):
            ep_num = ep.get('episodeNumber')
            ep_title = ep.get('title', f"الحلقة {ep_num}")
            add_video_item(f"▶️ {ep_title}", 'play_episode', item_id=item_id, season_num=season_num, ep_num=ep_num, icon=item.get('poster', ''))
        xbmcplugin.endOfDirectory(HANDLE)
    
    def resolve_and_play(sources, title_prefix="", next_episode_callback=None):
        if not sources:
            xbmcgui.Dialog().notification("عفواً", "لا توجد مصادر بث متاحة لهذا العمل", 'error')
            return
        options = []
        for s in sources:
            prov = s.get('providerName', 'سيرفر عام')
            qual = s.get('quality', 'HD')
            options.append(f"🔗 {prov} - جودة [{qual}]")
        selected_index = 0
        if len(sources) > 1:
            dialog = xbmcgui.Dialog()
            selected_index = dialog.select(f"اختر سيرفر التشغيل: {title_prefix}", options)
            if selected_index < 0: return
        selected_source = sources[selected_index]
        stream_url = selected_source.get('streamUrl')
        listitem = xbmcgui.ListItem(path=stream_url)
        set_video_info(listitem, title_prefix)
        player = xbmc.Player()
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem)
        if next_episode_callback and "True" == "True":
            monitor = xbmc.Monitor()
            while player.isPlaying():
                if monitor.waitForAbort(1): break
                try:
                    total_time = player.getTotalTime()
                    curr_time = player.getTime()
                    if total_time > 0 and (total_time - curr_time) <= 8:
                        xbmcgui.Dialog().notification("AmerTV AutoNext", "جاري تجهيز الحلقة التالية...", 'info', 4000)
                        time.sleep(4)
                        next_episode_callback()
                        break
                except:
                    pass
    
    def play_movie_handler(item_id):
        data = load_database()
        item = next((i for i in data.get('items', []) if i.get('id') == item_id), None)
        if item and 'sources' in item:
            resolve_and_play(item.get('sources'), title_prefix=item.get('title'))
    
    def play_episode_handler(item_id, season_num, ep_num):
        data = load_database()
        item = next((i for i in data.get('items', []) if i.get('id') == item_id), None)
        if not item: return
        season = next((s for s in item.get('seasons', []) if s.get('seasonNumber') == int(season_num)), None)
        if not season: return
        episodes = season.get('episodes', [])
        ep_index = next((idx for idx, e in enumerate(episodes) if e.get('episodeNumber') == int(ep_num)), None)
        if ep_index is None: return
        current_ep = episodes[ep_index]
        def play_next():
            if ep_index + 1 < len(episodes):
                next_ep = episodes[ep_index + 1]
                play_episode_handler(item_id, season_num, next_ep.get('episodeNumber'))
        resolve_and_play(
            current_ep.get('sources', []), 
            title_prefix=f"{item.get('title')} - S{season_num}E{ep_num}",
            next_episode_callback=play_next
        )
    
    EMBEDDED_DATABASE = json.loads(base64.b64decode("eyJ2ZXJzaW9uIjoiMS4wLjIiLCJ1cGRhdGVkQXQiOiIyMDI2LTA3LTI2VDIxOjA2OjIwLjk4N1oiLCJpdGVtcyI6W3siaWQiOiJtb3ZpZS0xMDEiLCJ0aXRsZSI6ItmB2YrZhNmFINin2YTYrdix2YrZgdipIDIgKNin2YTYsdmK2YXZiNmG2KrYp9iv2KcpIiwidHlwZSI6Im1vdmllIiwiY2F0ZWdvcnkiOiLYo9mB2YTYp9mFINi52LHYqNmK2KkiLCJ5ZWFyIjoyMDI1LCJkYXRlQWRkZWQiOiIyMDI2LTA3LTI1VDEyOjAwOjAwWiIsInBvc3RlciI6Imh0dHBzOi8vaW1hZ2VzLnVuc3BsYXNoLmNvbS9waG90by0xNTM2NDQwMTM2NjI4LTg0OWMxNzdlNzZhMT93PTUwMCZxPTgwIiwiZGVzY3JpcHRpb24iOiLYqtiv2YjYsSDYp9mE2KPYrdiv2KfYqyDYrdmI2YQg2KfYs9iq2YPZhdin2YQg2LHYrdmE2Kkg2YXYp9is2K8g2YjYo9i12K/Zgtin2KbZhyDZgdmKINi52KfZhNmFINmD2LHYqSDYp9mE2LTZiNin2LHYuSDZiNin2YTYrNin2YXYudin2Kog2YXYuSDYqtit2K/Zitin2Kog2KzYr9mK2K/YqS4iLCJyYXRpbmciOiI4LjQiLCJzb3VyY2VzIjpbeyJwcm92aWRlck5hbWUiOiLYudix2Kgg2YPYp9mB2YrZhyAoQXJhYkNhZmUpIiwicXVhbGl0eSI6IjEwODBwIiwic3RyZWFtVXJsIjoiaHR0cHM6Ly9hcmFiY2FmZS5uZXQvd2F0Y2gvZWwtaGFyZWVmYS0yLm1wNCIsImlzRGlyZWN0Ijp0cnVlfSx7InByb3ZpZGVyTmFtZSI6Itij2YPZiNin2YUgKEFrd2FtKSIsInF1YWxpdHkiOiIxMDgwcCIsInN0cmVhbVVybCI6Imh0dHBzOi8vYWt3YW0uY3ovZG93bmxvYWQvZWwtaGFyZWVmYS0yLWZoZC5tcDQiLCJpc0RpcmVjdCI6dHJ1ZX0seyJwcm92aWRlck5hbWUiOiLYpdmK2KzZiiDYqNiz2KogKEVneUJlc3QpIiwicXVhbGl0eSI6IjcyMHAiLCJzdHJlYW1VcmwiOiJodHRwczovL2VneWJlc3QubmV0L3N0cmVhbS9oYXJlZWZhMi5tM3U4IiwiaXNEaXJlY3QiOmZhbHNlfSx7InByb3ZpZGVyTmFtZSI6ItmB2KfYtdmEINil2LnZhNin2YbZiiAoRmFzZWxIRCkiLCJxdWFsaXR5IjoiMTA4MHAiLCJzdHJlYW1VcmwiOiJodHRwczovL2Zhc2VsaGQuYXBwL3ZpZGVvL2VsaGFyZWVmYTIiLCJpc0RpcmVjdCI6dHJ1ZX0seyJwcm92aWRlck5hbWUiOiLYudix2Kgg2LPZitivIChBcmFiU2VlZCkiLCJxdWFsaXR5IjoiNEsiLCJzdHJlYW1VcmwiOiJodHRwczovL2FyYWJzZWVkLm5ldC93YXRjaC9lbGhhcmVlZmEyLTRrLm1wNCIsImlzRGlyZWN0Ijp0cnVlfV19LHsiaWQiOiJzZXJpZXMtMjAxIiwidGl0bGUiOiLZhdiz2YTYs9mEINin2YTYrdi02KfYtNmK2YYiLCJ0eXBlIjoic2VyaWVzIiwiY2F0ZWdvcnkiOiLZhdiz2YTYs9mE2KfYqiDYudix2KjZitipIiwieWVhciI6MjAyNCwiZGF0ZUFkZGVkIjoiMjAyNi0wNy0yNFQxODozMDowMFoiLCJwb3N0ZXIiOiJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU3ODYzMjc2NzExNS0zNTE1OTdjZjI0Nzc/dz01MDAmcT04MCIsImRlc2NyaXB0aW9uIjoi2YHZiiDYpdi32KfYsSDYqtin2LHZitiu2Yog2LPZhNmK2YUg2K3ZiNmEINit2LPZhiDYp9mE2LXYqNin2K0g2YjZgdix2YLYqSDYp9mE2K3YtNin2LTZitmGINmB2Yog2KfZhNmC2LHZhiDYp9mE2K3Yp9iv2Yog2LnYtNixLiIsInJhdGluZyI6IjkuMSIsInNlYXNvbnMiOlt7InNlYXNvbk51bWJlciI6MSwidGl0bGUiOiLYp9mE2YXZiNiz2YUg2KfZhNij2YjZhCIsImVwaXNvZGVzIjpbeyJlcGlzb2RlTnVtYmVyIjoxLCJ0aXRsZSI6Itin2YTYrdmE2YLYqSAxIC0g2KfZhNi52YfYryIsInNvdXJjZXMiOlt7InByb3ZpZGVyTmFtZSI6Iti52LHYqCDZg9in2YHZitmHIChBcmFiQ2FmZSkiLCJxdWFsaXR5IjoiMTA4MHAiLCJzdHJlYW1VcmwiOiJodHRwczovL2FyYWJjYWZlLm5ldC93YXRjaC9oYXNoYXNoaW4tZXAxLm1wNCIsImlzRGlyZWN0Ijp0cnVlfSx7InByb3ZpZGVyTmFtZSI6Itij2YPZiNin2YUgKEFrd2FtKSIsInF1YWxpdHkiOiIxMDgwcCIsInN0cmVhbVVybCI6Imh0dHBzOi8vYWt3YW0uY3ovZG93bmxvYWQvaGFzaGFzaGluLWVwMS5tcDQiLCJpc0RpcmVjdCI6dHJ1ZX0seyJwcm92aWRlck5hbWUiOiLYudix2Kgg2LPZitivIChBcmFiU2VlZCkiLCJxdWFsaXR5IjoiNzIwcCIsInN0cmVhbVVybCI6Imh0dHBzOi8vYXJhYnNlZWQubmV0L3dhdGNoL2hhc2hhc2hpbi0xLm1wNCIsImlzRGlyZWN0Ijp0cnVlfV19LHsiZXBpc29kZU51bWJlciI6MiwidGl0bGUiOiLYp9mE2K3ZhNmC2KkgMiAtINmC2YTYudipINij2YTZhdmI2KoiLCJzb3VyY2VzIjpbeyJwcm92aWRlck5hbWUiOiLYudix2Kgg2YPYp9mB2YrZhyAoQXJhYkNhZmUpIiwicXVhbGl0eSI6IjEwODBwIiwic3RyZWFtVXJsIjoiaHR0cHM6Ly9hcmFiY2FmZS5uZXQvd2F0Y2gvaGFzaGFzaGluLWVwMi5tcDQiLCJpc0RpcmVjdCI6dHJ1ZX0seyJwcm92aWRlck5hbWUiOiLZgdin2LXZhCDYpdi52YTYp9mG2YogKEZhc2VsSEQpIiwicXVhbGl0eSI6IjEwODBwIiwic3RyZWFtVXJsIjoiaHR0cHM6Ly9mYXNlbGhkLmFwcC92aWRlby9oYXNoYXNoaW4tZXAyIiwiaXNEaXJlY3QiOnRydWV9LHsicHJvdmlkZXJOYW1lIjoi2KXZitis2Yog2KjYs9iqIChFZ3lCZXN0KSIsInF1YWxpdHkiOiI3MjBwIiwic3RyZWFtVXJsIjoiaHR0cHM6Ly9lZ3liZXN0Lm5ldC9zdHJlYW0vaGFzaGFzaGluLWVwMi5tM3U4IiwiaXNEaXJlY3QiOmZhbHNlfV19LHsiZXBpc29kZU51bWJlciI6MywidGl0bGUiOiLYp9mE2K3ZhNmC2KkgMyAtINin2YTZhdmI2KfYrNmH2KkiLCJzb3VyY2VzIjpbeyJwcm92aWRlck5hbWUiOiLYudix2Kgg2YPYp9mB2YrZhyAoQXJhYkNhZmUpIiwicXVhbGl0eSI6IjEwODBwIiwic3RyZWFtVXJsIjoiaHR0cHM6Ly9hcmFiY2FmZS5uZXQvd2F0Y2gvaGFzaGFzaGluLWVwMy5tcDQiLCJpc0RpcmVjdCI6dHJ1ZX0seyJwcm92aWRlck5hbWUiOiLYo9mD2YjYp9mFIChBa3dhbSkiLCJxdWFsaXR5IjoiMTA4MHAiLCJzdHJlYW1VcmwiOiJodHRwczovL2Frd2FtLmN6L2Rvd25sb2FkL2hhc2hhc2hpbi1lcDMubXA0IiwiaXNEaXJlY3QiOnRydWV9XX1dfV19LHsiaWQiOiJtb3ZpZS0xMDIiLCJ0aXRsZSI6IkR1bmU6IFBhcnQgVHdvICjYp9mE2YPYq9io2KfZhjog2KfZhNis2LLYoSDYp9mE2KvYp9mG2YopIiwidHlwZSI6Im1vdmllIiwiY2F0ZWdvcnkiOiLYo9mB2YTYp9mFINij2KzZhtio2YrYqSIsInllYXIiOjIwMjQsImRhdGVBZGRlZCI6IjIwMjYtMDctMjJUMDk6MTU6MDBaIiwicG9zdGVyIjoiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MTg3MDkyNjg4MDUtNGU5MDQyYWY5ZjIzP3c9NTAwJnE9ODAiLCJkZXNjcmlwdGlvbiI6ItmK2KrYrdivINio2YjZhCDYo9iq2LHZitiv2LMg2YXYuSDYqti02KfZhtmKINmI2KfZhNi02LnYqCDYp9mE2YHYsdmK2YXZhiDZgdmKINmF2LPYudin2Ycg2YTZhNin2YbYqtmC2KfZhSDZhdmGINin2YTZhdiq2KLZhdix2YrZhiDYp9mE2LDZitmGINiv2YXYsdmI2Kcg2LnYp9im2YTYqtmHLiIsInJhdGluZyI6IjguOCIsInNvdXJjZXMiOlt7InByb3ZpZGVyTmFtZSI6Iti52LHYqCDZg9in2YHZitmHIChBcmFiQ2FmZSkiLCJxdWFsaXR5IjoiNEsiLCJzdHJlYW1VcmwiOiJodHRwczovL2FyYWJjYWZlLm5ldC93YXRjaC9kdW5lLXBhcnQtMi00ay5tcDQiLCJpc0RpcmVjdCI6dHJ1ZX0seyJwcm92aWRlck5hbWUiOiLYs9mK2YXYpyDZgdmI2LEg2YrZiCAoQ2ltYTRVKSIsInF1YWxpdHkiOiIxMDgwcCIsInN0cmVhbVVybCI6Imh0dHBzOi8vY2ltYTR1Lm9uZS9zdHJlYW0vZHVuZS0yLWJsdXJheS5tcDQiLCJpc0RpcmVjdCI6dHJ1ZX0seyJwcm92aWRlck5hbWUiOiLZgdin2LXZhCDYpdi52YTYp9mG2YogKEZhc2VsSEQpIiwicXVhbGl0eSI6IjEwODBwIiwic3RyZWFtVXJsIjoiaHR0cHM6Ly9mYXNlbGhkLmFwcC92aWRlby9kdW5lLTItc3ViIiwiaXNEaXJlY3QiOnRydWV9LHsicHJvdmlkZXJOYW1lIjoi2KXZitis2Yog2KjYs9iqIChFZ3lCZXN0KSIsInF1YWxpdHkiOiI3MjBwIiwic3RyZWFtVXJsIjoiaHR0cHM6Ly9lZ3liZXN0Lm5ldC9zdHJlYW0vZHVuZS1wYXJ0Mi5tM3U4IiwiaXNEaXJlY3QiOmZhbHNlfV19LHsiaWQiOiJzZXJpZXMtMjAyIiwidGl0bGUiOiLZhdiz2YTYs9mEINiu2KfYsdmBICjYo9mG2YXZiiDZh9is2YjZhSDYp9mE2LnZhdin2YTZgtipIC0g2KfZhNmF2YjYs9mFINin2YTYo9iu2YrYsSkiLCJ0eXBlIjoic2VyaWVzIiwiY2F0ZWdvcnkiOiLYo9mG2YXZiiIsInllYXIiOjIwMjMsImRhdGVBZGRlZCI6IjIwMjYtMDctMjBUMTU6MDA6MDBaIiwicG9zdGVyIjoiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1NjMwODkxNDUtNTk5OTk3Njc0ZDQyP3c9NTAwJnE9ODAiLCJkZXNjcmlwdGlvbiI6Itin2YTZhdix2K3ZhNipINin2YTYrtiq2KfZhdmK2Kkg2YTYsdit2YTYqSDYp9mK2LHZitmGINmK2YrYutixINmI2KfZhNi12LHYp9i5INin2YTZhtmH2KfYptmKINmE2K3YsdmK2Kkg2KfZhNio2LTYsdmK2KkuIiwicmF0aW5nIjoiOS4yIiwic2Vhc29ucyI6W3sic2Vhc29uTnVtYmVyIjo0LCJ0aXRsZSI6Itin2YTZhdmI2LPZhSDYp9mE2LHYp9io2Lkg2YjYp9mE2YbZh9in2KbZiiIsImVwaXNvZGVzIjpbeyJlcGlzb2RlTnVtYmVyIjoxLCJ0aXRsZSI6Itin2YTYrdmE2YLYqSAxIC0g2KfZhNis2KfZhtioINin2YTYotiu2LEg2YXZhiDYp9mE2KjYrdixIiwic291cmNlcyI6W3sicHJvdmlkZXJOYW1lIjoi2LnYsdioINmD2KfZgdmK2YcgKEFyYWJDYWZlKSIsInF1YWxpdHkiOiIxMDgwcCIsInN0cmVhbVVybCI6Imh0dHBzOi8vYXJhYmNhZmUubmV0L3dhdGNoL2FvdC1zNC1lMS5tcDQiLCJpc0RpcmVjdCI6dHJ1ZX0seyJwcm92aWRlck5hbWUiOiLYudix2Kgg2LPZitivIChBcmFiU2VlZCkiLCJxdWFsaXR5IjoiMTA4MHAiLCJzdHJlYW1VcmwiOiJodHRwczovL2FyYWJzZWVkLm5ldC93YXRjaC9hb3QtczQtZTEubXA0IiwiaXNEaXJlY3QiOnRydWV9XX0seyJlcGlzb2RlTnVtYmVyIjoyLCJ0aXRsZSI6Itin2YTYrdmE2YLYqSAyIC0g2KfZhNmC2LfYp9ixINin2YTZhNmK2YTZiiIsInNvdXJjZXMiOlt7InByb3ZpZGVyTmFtZSI6Iti52LHYqCDZg9in2YHZitmHIChBcmFiQ2FmZSkiLCJxdWFsaXR5IjoiMTA4MHAiLCJzdHJlYW1VcmwiOiJodHRwczovL2FyYWJjYWZlLm5ldC93YXRjaC9hb3QtczQtZTIubXA0IiwiaXNEaXJlY3QiOnRydWV9LHsicHJvdmlkZXJOYW1lIjoi2KPZg9mI2KfZhSAoQWt3YW0pIiwicXVhbGl0eSI6IjEwODBwIiwic3RyZWFtVXJsIjoiaHR0cHM6Ly9ha3dhbS5jei9kb3dubG9hZC9hb3QtczQtZTIubXA0IiwiaXNEaXJlY3QiOnRydWV9XX1dfV19XX0=").decode('utf-8'))
    
    params = get_params()
    mode = params.get('mode')
    if mode is None:
        main_menu()
    elif mode == 'view_all_sorted':
        view_items()
    elif mode == 'view_category':
        view_items(category=params.get('category'))
    elif mode == 'view_seasons':
        view_seasons(params.get('url'))
    elif mode == 'view_episodes':
        view_episodes(params.get('url'))
    elif mode == 'play_movie':
        play_movie_handler(params.get('item_id'))
    elif mode == 'play_episode':
        play_episode_handler(params.get('item_id'), params.get('season'), params.get('episode'))
    elif mode == 'force_update_db':
        db_path = get_local_db_path()
        check_and_update_db(db_path)
        xbmcgui.Dialog().ok("AmerTV", "تمت عملية فحص وتحديث الميديا بنجاح!")
        main_menu()
    
except Exception as e:
    xbmcgui.Dialog().textviewer("AmerTV Error", traceback.format_exc())
