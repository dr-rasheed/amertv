# -*- coding: utf-8 -*-
# ==============================================================================
# Kodi Addon: AmerTV Matrix & ZombiB Repository (plugin.video.amertv)
# Repository Host: https://raw.githubusercontent.com/dr-rasheed/amertv/main
# Auto-Generated Python Core (Kodi 19 Matrix / 20 Nexus / 21 Omega)
# Includes: Multi-Source Scraping, Auto Database Sync, Auto Next Episode
# ==============================================================================

import sys
import os
import urllib.parse
import json
import time
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import requests
from bs4 import BeautifulSoup

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_ID = "plugin.video.amertv"
REMOTE_DB_URL = "https://raw.githubusercontent.com/dr-rasheed/amertv/main/media_database.json"

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'ar,en-US;q=0.9,en;q=0.8',
}

# ------------------------------------------------------------------------------
# LOCAL DATABASE & AUTO-UPDATE ENGINE
# ------------------------------------------------------------------------------
def get_local_db_path():
    profile_path = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/")
    if not os.path.exists(profile_path):
        os.makedirs(profile_path)
    return os.path.join(profile_path, "media_database.json")

def load_database():
    db_path = get_local_db_path()
    
    # 1. Check for remote updates if enabled
    check_and_update_db(db_path)

    # 2. Load from local cache if exists
    if os.path.exists(db_path):
        try:
            with open(db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] Error reading local DB: {e}", xbmc.LOGERROR)

    # 3. Fallback Embedded Database
    return EMBEDDED_DATABASE

def check_and_update_db(db_path):
    """ يفحص هل تم تحديث قاعدة البيانات على سيرفر GitHub أم لا ويقوم بتحديثها تلقائياً """
    try:
        response = requests.get(REMOTE_DB_URL, headers=HEADERS, timeout=5)
        if response.status_code == 200:
            remote_data = response.json()
            
            should_update = True
            if os.path.exists(db_path):
                with open(db_path, 'r', encoding='utf-8') as f:
                    local_data = json.load(f)
                    if local_data.get('version') == remote_data.get('version'):
                        should_update = False

            if should_update:
                with open(db_path, 'w', encoding='utf-8') as f:
                    json.dump(remote_data, f, ensure_ascii=False, indent=2)
                xbmcgui.Dialog().notification("AmerTV Repository", "تم تحديث مكتبة الأفلام والمسلسلات بنجاح!", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Online DB sync skipped: {e}", xbmc.LOGINFO)

# ------------------------------------------------------------------------------
# ROUTING & UI HELPERS
# ------------------------------------------------------------------------------
def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        cleaned = paramstring.replace('?', '')
        pairs = cleaned.split('&')
        for pair in pairs:
            split = pair.split('=')
            if len(split) == 2:
                param[split[0]] = urllib.parse.unquote_plus(split[1])
    return param

def add_folder(name, mode, url='', icon='', plot='', category=''):
    params = {'mode': mode, 'url': url, 'name': name, 'category': category}
    target = f"{BASE_URL}?{urllib.parse.urlencode(params)}"
    li = xbmcgui.ListItem(label=name)
    if icon:
        li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    if plot:
        li.setInfo('video', {'plot': plot, 'title': name})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=target, listitem=li, isFolder=True)

def add_video_item(name, mode, item_id='', season_num=0, ep_num=0, icon='', plot=''):
    params = {
        'mode': mode, 
        'item_id': item_id, 
        'season': season_num, 
        'episode': ep_num, 
        'name': name
    }
    target = f"{BASE_URL}?{urllib.parse.urlencode(params)}"
    li = xbmcgui.ListItem(label=name)
    if icon:
        li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    if plot:
        li.setInfo('video', {'plot': plot, 'title': name})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=target, listitem=li, isFolder=False)

# ------------------------------------------------------------------------------
# VIEWS & NAVIGATION
# ------------------------------------------------------------------------------
def main_menu():
    """ الشاشة الرئيسية المرتبة حسب التصنيفات والمستودع """
    xbmcplugin.setContent(HANDLE, 'files')
    
    add_folder("🔥 أحدث الإضافات والتحديثات (الكل مرتب)", "view_all_sorted", icon="", plot="جميع الأفلام والمسلسلات مرتبة من الأحدث للأقدم")
    add_folder("🎬 أفلام عربية", "view_category", category="أفلام عربية", plot="أحدث الأفلام العربية بمصادر سيرفرات متعددة")
    add_folder("🍿 أفلام أجنبية مترجمة", "view_category", category="أفلام أجنبية", plot="أفلام هوليوود والغربية مترجمة بأعلى دقة")
    add_folder("📺 مسلسلات عربية", "view_category", category="مسلسلات عربية", plot="مسلسلات رمضان والدراما العربية مع الانتقال التلقائي بين الحلقات")
    add_folder("🌍 مسلسلات أجنبية", "view_category", category="مسلسلات أجنبية", plot="مسلسلات أجنبية عالمية مترجمة")
    add_folder("⛩️ أنمي وكرتون", "view_category", category="أنمي", plot="حلقات وأفلام الأنمي المترجمة والمدبلجة")
    add_folder("🌐 كاشط الميديا المباشر (المواقع المتاحة)", "view_live_scrapers", plot="كشط مباشر من مواقع عرب كافيه، أكوام، إيجي بست، فاصل إعلاني")
    add_folder("🔄 فحص تحديث قاعدة البيانات الان", "force_update_db", plot="تحديث دليل الأفلام والمسلسلات من مستودع GitHub")

    xbmcplugin.endOfDirectory(HANDLE)

def view_items(category=None):
    """ عرض قائمة الأعمال مرتبة دائماً من الأحدث إلى الأقدم """
    data = load_database()
    items = data.get('items', [])

    # تصفية حسب القسم إن وجد
    if category:
        items = [i for i in items if i.get('category') == category]

    # فرز العمليات تاريخياً من الأحدث للأقدم
    items.sort(key=lambda x: x.get('dateAdded', ''), reverse=True)

    for item in items:
        item_type = item.get('type')
        title = f"[{item.get('year', '')}] {item.get('title')}"
        icon = item.get('poster', '')
        plot = item.get('description', '')

        if item_type == 'movie':
            add_video_item(f"🎬 {title}", 'play_movie', item_id=item.get('id'), icon=icon, plot=plot)
        else:
            add_folder(f"📺 {title}", 'view_seasons', url=item.get('id'), icon=icon, plot=plot)

    xbmcplugin.endOfDirectory(HANDLE)

def view_seasons(item_id):
    """ عرض مواسم المسلسل """
    data = load_database()
    item = next((i for i in data.get('items', []) if i.get('id') == item_id), None)
    if not item or 'seasons' not in item:
        xbmcgui.Dialog().notification("خطأ", "لم يتم العثور على مواسم لهذا المسلسل", xbmcgui.NOTIFICATION_WARNING)
        return

    for season in item.get('seasons', []):
        s_num = season.get('seasonNumber')
        s_title = season.get('title', f"الموسم {s_num}")
        add_folder(f"📂 {s_title}", 'view_episodes', url=f"{item_id}|{s_num}", icon=item.get('poster', ''), plot=item.get('description', ''))

    xbmcplugin.endOfDirectory(HANDLE)

def view_episodes(season_payload):
    """ عرض حلقات الموسم """
    item_id, season_num = season_payload.split('|')
    season_num = int(season_num)

    data = load_database()
    item = next((i for i in data.get('items', []) if i.get('id') == item_id), None)
    if not item:
        return

    season = next((s for s in item.get('seasons', []) if s.get('seasonNumber') == season_num), None)
    if not season:
        return

    for ep in season.get('episodes', []):
        ep_num = ep.get('episodeNumber')
        ep_title = ep.get('title', f"الحلقة {ep_num}")
        add_video_item(f"▶️ {ep_title}", 'play_episode', item_id=item_id, season_num=season_num, ep_num=ep_num, icon=item.get('poster', ''))

    xbmcplugin.endOfDirectory(HANDLE)

# ------------------------------------------------------------------------------
# MULTI-SOURCE RESOLVER & AUTO-NEXT EPISODE PLAYER
# ------------------------------------------------------------------------------
def resolve_and_play(sources, title_prefix="", next_episode_callback=None):
    """ عرض قائمة السيرفرات والمصادر المتاحة واختيار أحدها للتشغيل """
    if not sources:
        xbmcgui.Dialog().notification("عفواً", "لا توجد مصادر بث متاحة لهذا العمل", xbmcgui.NOTIFICATION_ERROR)
        return

    # إنشاء قائمة الاختيارات للمستخدم (اسم السيرفر + الجودة)
    options = []
    for s in sources:
        prov = s.get('providerName', 'سيرفر عام')
        qual = s.get('quality', 'HD')
        options.append(f"🔗 {prov} - جودة [{qual}]")

    # إن كان هناك مصدر واحد شغّله فوراً، وإلا اظهر قائمة السيرفرات
    selected_index = 0
    if len(sources) > 1:
        dialog = xbmcgui.Dialog()
        selected_index = dialog.select(f"اختر سيرفر التشغيل: {title_prefix}", options)
        if selected_index < 0:
            return # cancel

    selected_source = sources[selected_index]
    stream_url = selected_source.get('streamUrl')

    # إنشاء مشغل كودي
    listitem = xbmcgui.ListItem(path=stream_url)
    listitem.setInfo('video', {'title': title_prefix})
    
    player = xbmc.Player()
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem)

    # خاصية الانتقال التلقائي للحلقة التالية للمسلسلات
    if next_episode_callback and "True" == "True":
        monitor = xbmc.Monitor()
        while player.isPlaying():
            if monitor.waitForAbort(1):
                break
            # إذا شارف الفيديو على الانتهاء (أقل من 10 ثواني)
            try:
                total_time = player.getTotalTime()
                curr_time = player.getTime()
                if total_time > 0 and (total_time - curr_time) <= 8:
                    xbmcgui.Dialog().notification("AmerTV AutoNext", "جاري تجهيز الحلقة التالية...", xbmcgui.NOTIFICATION_INFO, 4000)
                    time.sleep(4)
                    next_episode_callback()
                    break
            except:
                pass

def play_movie_handler(item_id):
    data = load_database()
    item = next((i for i in data.get('items', []) if i.get('id') == item_id), None)
    if item and 'sources' in item:
        resolve_and_play(item.get('sources'), title_prefix=item.get('title'))

def play_episode_handler(item_id, season_num, ep_num):
    data = load_database()
    item = next((i for i in data.get('items', []) if i.get('id') == item_id), None)
    if not item:
        return

    season = next((s for s in item.get('seasons', []) if s.get('seasonNumber') == int(season_num)), None)
    if not season:
        return

    episodes = season.get('episodes', [])
    ep_index = next((idx for idx, e in enumerate(episodes) if e.get('episodeNumber') == int(ep_num)), None)
    if ep_index is None:
        return

    current_ep = episodes[ep_index]

    # callback للحلقة التالية
    def play_next():
        if ep_index + 1 < len(episodes):
            next_ep = episodes[ep_index + 1]
            play_episode_handler(item_id, season_num, next_ep.get('episodeNumber'))

    resolve_and_play(
        current_ep.get('sources', []), 
        title_prefix=f"{item.get('title')} - S{season_num}E{ep_num}",
        next_episode_callback=play_next
    )

# ------------------------------------------------------------------------------
# EMBEDDED FALLBACK DATABASE
# ------------------------------------------------------------------------------
EMBEDDED_DATABASE = {
  "version": "1.0.2",
  "updatedAt": "2026-07-26T18:23:26.141Z",
  "items": [
  {
    "id": "movie-101",
    "title": "فيلم الحريفة 2 (الريمونتادا)",
    "type": "movie",
    "category": "أفلام عربية",
    "year": 2025,
    "dateAdded": "2026-07-25T12:00:00Z",
    "poster": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&q=80",
    "description": "تدور الأحداث حول استكمال رحلة ماجد وأصدقائه في عالم كرة الشوارع والجامعات مع تحديات جديدة.",
    "rating": "8.4",
    "sources": [
      {
        "providerName": "عرب كافيه (ArabCafe)",
        "quality": "1080p",
        "streamUrl": "https://arabcafe.net/watch/el-hareefa-2.mp4",
        "isDirect": true
      },
      {
        "providerName": "أكوام (Akwam)",
        "quality": "1080p",
        "streamUrl": "https://akwam.cz/download/el-hareefa-2-fhd.mp4",
        "isDirect": true
      },
      {
        "providerName": "إيجي بست (EgyBest)",
        "quality": "720p",
        "streamUrl": "https://egybest.net/stream/hareefa2.m3u8",
        "isDirect": false
      },
      {
        "providerName": "فاصل إعلاني (FaselHD)",
        "quality": "1080p",
        "streamUrl": "https://faselhd.app/video/elhareefa2",
        "isDirect": true
      },
      {
        "providerName": "عرب سيد (ArabSeed)",
        "quality": "4K",
        "streamUrl": "https://arabseed.net/watch/elhareefa2-4k.mp4",
        "isDirect": true
      }
    ]
  },
  {
    "id": "series-201",
    "title": "مسلسل الحشاشين",
    "type": "series",
    "category": "مسلسلات عربية",
    "year": 2024,
    "dateAdded": "2026-07-24T18:30:00Z",
    "poster": "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&q=80",
    "description": "في إطار تاريخي سليم حول حسن الصباح وفرقة الحشاشين في القرن الحادي عشر.",
    "rating": "9.1",
    "seasons": [
      {
        "seasonNumber": 1,
        "title": "الموسم الأول",
        "episodes": [
          {
            "episodeNumber": 1,
            "title": "الحلقة 1 - العهد",
            "sources": [
              {
                "providerName": "عرب كافيه (ArabCafe)",
                "quality": "1080p",
                "streamUrl": "https://arabcafe.net/watch/hashashin-ep1.mp4",
                "isDirect": true
              },
              {
                "providerName": "أكوام (Akwam)",
                "quality": "1080p",
                "streamUrl": "https://akwam.cz/download/hashashin-ep1.mp4",
                "isDirect": true
              },
              {
                "providerName": "عرب سيد (ArabSeed)",
                "quality": "720p",
                "streamUrl": "https://arabseed.net/watch/hashashin-1.mp4",
                "isDirect": true
              }
            ]
          },
          {
            "episodeNumber": 2,
            "title": "الحلقة 2 - قلعة ألموت",
            "sources": [
              {
                "providerName": "عرب كافيه (ArabCafe)",
                "quality": "1080p",
                "streamUrl": "https://arabcafe.net/watch/hashashin-ep2.mp4",
                "isDirect": true
              },
              {
                "providerName": "فاصل إعلاني (FaselHD)",
                "quality": "1080p",
                "streamUrl": "https://faselhd.app/video/hashashin-ep2",
                "isDirect": true
              },
              {
                "providerName": "إيجي بست (EgyBest)",
                "quality": "720p",
                "streamUrl": "https://egybest.net/stream/hashashin-ep2.m3u8",
                "isDirect": false
              }
            ]
          },
          {
            "episodeNumber": 3,
            "title": "الحلقة 3 - المواجهة",
            "sources": [
              {
                "providerName": "عرب كافيه (ArabCafe)",
                "quality": "1080p",
                "streamUrl": "https://arabcafe.net/watch/hashashin-ep3.mp4",
                "isDirect": true
              },
              {
                "providerName": "أكوام (Akwam)",
                "quality": "1080p",
                "streamUrl": "https://akwam.cz/download/hashashin-ep3.mp4",
                "isDirect": true
              }
            ]
          }
        ]
      }
    ]
  },
  {
    "id": "movie-102",
    "title": "Dune: Part Two (الكثبان: الجزء الثاني)",
    "type": "movie",
    "category": "أفلام أجنبية",
    "year": 2024,
    "dateAdded": "2026-07-22T09:15:00Z",
    "poster": "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&q=80",
    "description": "يتحد بول أتريدس مع تشاني والشعب الفريمن في مسعاه للانتقام من المتآمرين الذين دمروا عائلته.",
    "rating": "8.8",
    "sources": [
      {
        "providerName": "عرب كافيه (ArabCafe)",
        "quality": "4K",
        "streamUrl": "https://arabcafe.net/watch/dune-part-2-4k.mp4",
        "isDirect": true
      },
      {
        "providerName": "سيما فور يو (Cima4U)",
        "quality": "1080p",
        "streamUrl": "https://cima4u.one/stream/dune-2-bluray.mp4",
        "isDirect": true
      },
      {
        "providerName": "فاصل إعلاني (FaselHD)",
        "quality": "1080p",
        "streamUrl": "https://faselhd.app/video/dune-2-sub",
        "isDirect": true
      },
      {
        "providerName": "إيجي بست (EgyBest)",
        "quality": "720p",
        "streamUrl": "https://egybest.net/stream/dune-part2.m3u8",
        "isDirect": false
      }
    ]
  },
  {
    "id": "series-202",
    "title": "مسلسل خارف (أنمي هجوم العمالقة - الموسم الأخير)",
    "type": "series",
    "category": "أنمي",
    "year": 2023,
    "dateAdded": "2026-07-20T15:00:00Z",
    "poster": "https://images.unsplash.com/photo-1563089145-599997674d42?w=500&q=80",
    "description": "المرحلة الختامية لرحلة ايرين ييغر والصراع النهائي لحرية البشرية.",
    "rating": "9.2",
    "seasons": [
      {
        "seasonNumber": 4,
        "title": "الموسم الرابع والنهائي",
        "episodes": [
          {
            "episodeNumber": 1,
            "title": "الحلقة 1 - الجانب الآخر من البحر",
            "sources": [
              {
                "providerName": "عرب كافيه (ArabCafe)",
                "quality": "1080p",
                "streamUrl": "https://arabcafe.net/watch/aot-s4-e1.mp4",
                "isDirect": true
              },
              {
                "providerName": "عرب سيد (ArabSeed)",
                "quality": "1080p",
                "streamUrl": "https://arabseed.net/watch/aot-s4-e1.mp4",
                "isDirect": true
              }
            ]
          },
          {
            "episodeNumber": 2,
            "title": "الحلقة 2 - القطار الليلي",
            "sources": [
              {
                "providerName": "عرب كافيه (ArabCafe)",
                "quality": "1080p",
                "streamUrl": "https://arabcafe.net/watch/aot-s4-e2.mp4",
                "isDirect": true
              },
              {
                "providerName": "أكوام (Akwam)",
                "quality": "1080p",
                "streamUrl": "https://akwam.cz/download/aot-s4-e2.mp4",
                "isDirect": true
              }
            ]
          }
        ]
      }
    ]
  }
]
}

# ------------------------------------------------------------------------------
# MAIN ENTRYPOINT & ROUTER
# ------------------------------------------------------------------------------
params = get_params()
mode = params.get('mode')

if mode is None:
    main_menu()
elif mode == 'view_all_sorted':
    view_items()
elif mode == 'view_category':
    view_items(category=params.get('category'))
elif mode == 'view_seasons':
    view_seasons(params.get('url'))
elif mode == 'view_episodes':
    view_episodes(params.get('url'))
elif mode == 'play_movie':
    play_movie_handler(params.get('item_id'))
elif mode == 'play_episode':
    play_episode_handler(params.get('item_id'), params.get('season'), params.get('episode'))
elif mode == 'force_update_db':
    db_path = get_local_db_path()
    check_and_update_db(db_path)
    xbmcgui.Dialog().ok("AmerTV", "تمت عملية فحص وتحديث الميديا بنجاح!")
    main_menu()
